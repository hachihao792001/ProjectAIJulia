struct SimpleGame
      γ  # discount factor
      ℐ  # agents
      𝒜  # joint action space
      R  # joint reward function
end
