struct DiscreteMDP
    T::Array{Float64, 3} 
    R::Array{Float64, 2}
    γ::Float64
end

